<?php
/**
 * Plugin Name: Themeum Demo Importer
 * Plugin URI: http://www.themeum.com
 * Description: Themeum Demo Importer is ultimate event plugins
 * Author: Themeum
 * Version: 1.0
 * Author URI: http://www.themeum.com
 *
 * Tested up to: 4.0
 * Text Domain: themeum-eventum
 *
 * @package Themeum Eventum
 * @category Core
 * @author Eventum
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
include_once( 'framework.php' );
include_once( 'import-functions.php' );

